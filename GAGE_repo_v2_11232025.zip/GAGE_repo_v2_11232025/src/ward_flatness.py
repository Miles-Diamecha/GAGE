#!/usr/bin/env python3
import numpy as np
import json

# ---------------------------------------------------------
# 2-loop beta functions (MS-bar, SM-like conventions)
# d alpha / d ln Q = beta(alpha)
#
# For SU(3) and SU(2) we include 2-loop terms.
# For alpha_em we keep the 1-loop term only.
# ---------------------------------------------------------

# SU(3)_c: n_f ~ 5 at MZ  (standard QCD)
# beta(α_s) = -β0 α_s^2/(2π) - β1 α_s^3/(8π^2)
beta0_s = 23.0 / 3.0    # 11 - 2/3 n_f with n_f=5
beta1_s = 58.0 / 3.0    # 51 - 19/3 n_f

def beta_s(alpha_s):
    return -(beta0_s/(2.0*np.pi))*alpha_s**2 - (beta1_s/(8.0*np.pi**2))*alpha_s**3

# SU(2)_L: SM with 3 generations, 1 Higgs doublet
# We use canonical SM-like coefficients:
# beta(α_2) = -β0 α_2^2/(2π) - β1 α_2^3/(8π^2)
beta0_2 = 19.0 / 6.0
beta1_2 = 35.0 / 6.0

def beta_2(alpha2):
    return -(beta0_2/(2.0*np.pi))*alpha2**2 - (beta1_2/(8.0*np.pi**2))*alpha2**3

# U(1)_em: keep 1-loop only for simplicity
# beta(α) ≈ +b α^2  with b chosen to match your previous stub
def beta_em(alpha):
    return (41.0/(6.0*np.pi)) * alpha**2

# ---------------------------------------------------------
# aligned beta combination
# ---------------------------------------------------------
def betaXi(alpha_s, alpha2, alpha_em):
    # Use the full dα/dlnQ from the beta_* functions
    return (16.0*beta_s(alpha_s)/alpha_s
          + 13.0*beta_2(alpha2)/alpha2
          + 2.0 *beta_em(alpha_em)/alpha_em)

def F_sigma(betaXi_val, sigma_chi):
    return betaXi_val / sigma_chi

# ---------------------------------------------------------
# Generic 2-loop (or multi-loop) runner with RK4
# Integrates dα/dt = beta_func(α) from t=0 to t=t_target
# ---------------------------------------------------------
def run_alpha_2loop(alpha0, beta_func, t_target, n_steps=1000):
    if t_target == 0.0:
        return alpha0

    alpha = alpha0
    dt = t_target / float(n_steps)

    # Simple RK4 integrator in t = ln(Q / MZ)
    for _ in range(n_steps):
        k1 = beta_func(alpha)
        k2 = beta_func(alpha + 0.5*dt*k1)
        k3 = beta_func(alpha + 0.5*dt*k2)
        k4 = beta_func(alpha + dt*k3)
        alpha = alpha + (dt/6.0)*(k1 + 2*k2 + 2*k3 + k4)
        # Guard against unphysical negative alpha
        if alpha <= 0.0:
            return max(alpha, 1e-10)
    return alpha

# ---------------------------------------------------------
# Main
# ---------------------------------------------------------
if __name__=="__main__":
    # Input pins (from your repo_results.txt)
    alpha_s_MZ  = 0.117341100
    alpha2_MZ   = 0.033789820
    alphaem_MZ  = 1.0/127.955
    sigma_chi   = 247.683   # your pinned width

    Q_min = 10.0
    Q_max = 1.0e19
    n_pts = 500

    Qvals = np.logspace(np.log10(Q_min), np.log10(Q_max), n_pts)  # 10 GeV to 10^19 GeV
    MZ = 91.1876
    tvals = np.log(Qvals/MZ)

    stats = []
    for Q, t in zip(Qvals, tvals):
        a_s  = run_alpha_2loop(alpha_s_MZ, beta_s,  t)
        a2   = run_alpha_2loop(alpha2_MZ,  beta_2,  t)
        a_em = run_alpha_2loop(alphaem_MZ, beta_em, t)  # still 1-loop, but via same integrator

        bXi = betaXi(a_s, a2, a_em)
        F   = F_sigma(bXi, sigma_chi)

        stats.append({"Q": float(Q), "betaXi": float(bXi), "F_sigma": float(F)})

    Fs = [s["F_sigma"] for s in stats]

    out = {
        "max_F_sigma": float(np.max(Fs)),
        "min_F_sigma": float(np.min(Fs)),
        "avg_F_sigma": float(np.mean(Fs)),
        "grid": stats
    }

    with open("ward_flatness_results.json","w") as f:
        json.dump(out, f, indent=2)

    print("Done. Results written to ward_flatness_results.json")
