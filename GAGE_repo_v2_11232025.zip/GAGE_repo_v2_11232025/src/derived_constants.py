#!/usr/bin/env python3
"""
derived_constants.py

Compute and summarize GEOMETRY bookkeeping constants:

- sigma_chi (σχ)  : gate width (from results.json if available)
- F_chi           : Fisher curvature along χ, F_chi = 1 / σ_chi^2
- T_hel           : graviton helicity period, T_hel ≈ 88 t_P
- omega_hel       : helicity frequency, ω_hel = 1 / T_hel
- DeltaE_hel      : mass gap ΔE = ħ ω_hel

Outputs:
- prints a human-readable summary
- writes derived_constants.json with all values
"""

import json
import math
import os

# ---------------------------------------------------------------------
# Physical constants (CODATA 2018/2022 style; adjust if you have pins)
# ---------------------------------------------------------------------
hbar = 1.054_571_817e-34      # J s
c    = 2.997_924_58e8         # m / s
G_N  = 6.674_30e-11           # m^3 kg^-1 s^-2
eV_J = 1.602_176_634e-19      # J / eV

# Planck time (derived)
t_P = math.sqrt(hbar * G_N / c**5)  # s

# Helicity period ratio (from GEOMETRY II)
T_hel_over_tP = 88.0


def load_sigma_chi(default_sigma=247.683):
    """
    Try to read sigma_chi from results.json if available.
    Fallback to pinned value if file/field is missing.
    """
    candidates = ["results.json", "repo_results.json"]
    for fname in candidates:
        if os.path.exists(fname):
            try:
                with open(fname, "r") as f:
                    data = json.load(f)
                if "sigma_chi" in data:
                    return float(data["sigma_chi"])
            except Exception:
                pass
    return float(default_sigma)


def main():
    sigma_chi = load_sigma_chi()

    # Fisher curvature along χ
    F_chi = 1.0 / (sigma_chi ** 2)

    # Helicity period and frequency
    T_hel = T_hel_over_tP * t_P          # seconds
    omega_hel = 1.0 / T_hel              # s^-1 (Hz in angular-freq convention here)

    # Mass gap ΔE = ħ ω_hel
    DeltaE_J  = hbar * omega_hel         # joules
    DeltaE_eV = DeltaE_J / eV_J          # eV

    out = {
        "sigma_chi": sigma_chi,
        "F_chi": F_chi,
        "t_P_s": t_P,
        "T_hel_over_tP": T_hel_over_tP,
        "T_hel_s": T_hel,
        "omega_hel_Hz": omega_hel,
        "DeltaE_hel_J": DeltaE_J,
        "DeltaE_hel_eV": DeltaE_eV,
    }

    # Write JSON snapshot
    with open("derived_constants.json", "w") as f:
        json.dump(out, f, indent=2)

    # Human-readable summary
    print("GEOMETRY derived constants")
    print("---------------------------")
    print(f"sigma_chi      = {sigma_chi:.6f}")
    print(f"F_chi          = {F_chi:.6e}")
    print(f"t_P            = {t_P:.6e} s")
    print(f"T_hel / t_P    = {T_hel_over_tP:.3f}")
    print(f"T_hel          = {T_hel:.6e} s")
    print(f"omega_hel      = {omega_hel:.6e} s^-1")
    print(f"DeltaE_hel     = {DeltaE_eV:.6e} eV")

if __name__ == "__main__":
    main()
