#!/usr/bin/env python3
import hashlib, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
CANDIDATES = ["results.json", "metric_results.json", "stdout.txt"]

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def main(argv):
    # If args given, hash those; else hash existing candidates.
    files = []
    if argv:
        for name in argv:
            p = (HERE / name).resolve()
            if p.exists():
                files.append(p)
    else:
        for name in CANDIDATES:
            p = HERE / name
            if p.exists():
                files.append(p)

    with open(HERE / "SHA256SUMS.txt", "w", encoding="ascii") as outf:
        for p in files:
            line = f"{sha256_file(p)} {p.name}"
            print(line)
            outf.write(line + "\n")

if __name__ == "__main__":
    main(sys.argv[1:])
