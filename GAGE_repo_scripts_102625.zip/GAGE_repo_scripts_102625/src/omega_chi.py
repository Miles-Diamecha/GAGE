#!/usr/bin/env python3
import json, math

def load_pins(path="pins.json"):
    with open(path, "r") as f:
        return json.load(f)

def alpha2(alpha_em, sin2w):
    return alpha_em / sin2w

def omega_chi(alpha_s, alpha2_val, alpha_em):
    return (alpha_s**16) * (alpha2_val**13) * (alpha_em**2)

def alpha_G_pp(G_N, m_p, hbar, c):
    return G_N * (m_p**2) / (hbar * c)

def loo_alpha_s_star(alpha_Gpp, alpha2_val, alpha_em):
    return (alpha_Gpp / (alpha2_val**13 * alpha_em**2))**(1.0/16.0)

def main():
    pins = load_pins()
    P, G = pins["pins"], pins["gate"]

    alpha_em = 1.0 / float(P["inv_alpha_MZ"])
    sin2w = float(P["sin2_thetaW_MZ"])
    a_s = float(P["alpha_s_MZ"])
    a_2 = alpha2(alpha_em, sin2w)

    aGpp = alpha_G_pp(float(P["G_N_SI"]), float(P["m_p_SI_kg"]),
                      float(P["hbar_SI_Js"]), float(P["c_SI_mps"]))

    Om = omega_chi(a_s, a_2, alpha_em)
    closure = Om / aGpp
    a_s_star = loo_alpha_s_star(aGpp, a_2, alpha_em)

    Lambda_gate = float(G["sigma_chi"]) / float(G["K_eq_norm_chi"])

    out = {
        "alpha2_MZ": a_2,
        "Omega_chi": Om,
        "alpha_G_pp": aGpp,
        "closure_ratio_Omega_over_alphaGpp": closure,
        "alpha_s_star_MZ": a_s_star,
        "Lambda_gate": Lambda_gate
    }

    with open("results.json","w") as f:
        json.dump(out, f, indent=2, sort_keys=True)

    s = (f"alpha2(MZ) = {a_2:.9f}\n"
         f"Omega_chi = {Om:.12e}\n"
         f"alphaG_pp = {aGpp:.12e}\n"
         f"closure Omega_chi/alphaG_pp = {closure:.8f}\n"
         f"alpha_s* (LOO) = {a_s_star:.9f}\n"
         f"Lambda_gate = {Lambda_gate:.6f}\n")

    print(s)
    with open("stdout.txt","w") as f:
        f.write(s)

if __name__ == "__main__":
    main()
