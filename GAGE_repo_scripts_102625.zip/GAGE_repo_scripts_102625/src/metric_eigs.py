#!/usr/bin/env python3
# metric_eigs.py — K_eq eigens, ||chi||_K, alignment, Lambda_gate (ASCII-only)

import json, math, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent  # repo root

def load_json(name):
    # try src/ first, then repo root
    p = HERE / name
    if not p.exists():
        p = ROOT / name
    with open(p, "r") as f:
        return json.load(f)

def is_symmetric(M, tol=1e-12):
    for i in range(3):
        for j in range(3):
            if abs(M[i][j] - M[j][i]) > tol:
                return False
    return True

def matvec(M, v):
    return [sum(M[i][j]*v[j] for j in range(3)) for i in range(3)]

def dot(a, b):
    return sum(x*y for x, y in zip(a, b))

def eigen_decomp_sym(M):
    try:
        import numpy as np
        w, V = np.linalg.eigh(np.array(M, dtype=float))
        evecs = [[V[i, k] for i in range(3)] for k in range(3)]
        return w.tolist(), evecs
    except Exception:
        from sympy import Matrix
        mat = Matrix(M)
        evects = mat.eigenvects()
        pairs = []
        for ev, mult, vecs in evects:
            for v in vecs:
                vv = [float(x) for x in v]
                nrm = math.sqrt(sum(x*x for x in vv))
                if nrm == 0.0:
                    continue
                vv = [x/nrm for x in vv]
                pairs.append((float(ev), vv))
        pairs.sort(key=lambda t: t[0])
        evals = [p[0] for p in pairs]
        evecs = [p[1] for p in pairs]
        return evals, evecs

def main():
    pins = load_json("pins.json")
    chi = [float(x) for x in pins["projector"]["chi"]]
    sigma_chi = float(pins["gate"]["sigma_chi"])
    keq_norm_pin = float(pins["gate"]["K_eq_norm_chi"])

    K = load_json("keq.json")["K_eq"]
    if not is_symmetric(K):
        K = [[0.5*(K[i][j] + K[j][i]) for j in range(3)] for i in range(3)]

    # K-norm of chi
    Kchi = matvec(K, chi)
    chi_norm_K = math.sqrt(dot(chi, Kchi))

    # Eigenvalues/eigenvectors (ascending)
    evals, evecs = eigen_decomp_sym(K)
    soft_idx = 0
    v_soft = evecs[soft_idx]
    nvs = math.sqrt(dot(v_soft, v_soft))
    if nvs != 0.0:
        v_soft = [x/nvs for x in v_soft]

    # Alignment cosine (Euclidean)
    chi_norm = math.sqrt(dot(chi, chi))
    cos_theta = abs(dot(chi, v_soft) / chi_norm) if chi_norm != 0.0 else float("nan")

    # Gate scale
    Lambda_gate_calc = sigma_chi / chi_norm_K
    Lambda_gate_pin = sigma_chi / keq_norm_pin if keq_norm_pin != 0.0 else float("inf")

    # JSON artifact (repo root)
    out = {
        "K_eq": K,
        "eigvals_sorted": evals,
        "soft_index": soft_idx,
        "v_soft": v_soft,
        "chi": chi,
        "chi_norm_K": chi_norm_K,
        "chi_norm_K_pinned": keq_norm_pin,
        "chi_norm_K_diff": chi_norm_K - keq_norm_pin,
        "sigma_chi": sigma_chi,
        "Lambda_gate_calc": Lambda_gate_calc,
        "Lambda_gate_from_pins": Lambda_gate_pin,
        "Lambda_gate_diff": Lambda_gate_calc - Lambda_gate_pin,
        "alignment_cosine": cos_theta
    }
    with open(ROOT / "metric_results.json", "w", encoding="ascii") as f:
        json.dump(out, f, indent=2, sort_keys=True)

    # Human-readable summary (build first, then print and append)
    s = []
    s.append("K_eq eigenvalues (asc): " + ", ".join(f"{x:.7f}" for x in evals))
    s.append("Soft-mode eigenvector: (" + ", ".join(f"{x:.7f}" for x in v_soft) + ")")
    s.append(f"||chi||_K (computed): {chi_norm_K:.6f}")
    s.append(f"||chi||_K (pinned)  : {keq_norm_pin:.6f}")
    s.append(f"Lambda_gate (calc)  : {Lambda_gate_calc:.6f}")
    s.append(f"Lambda_gate (pins)  : {Lambda_gate_pin:.6f}")
    s.append(f"Lambda diff         : {Lambda_gate_calc - Lambda_gate_pin:.6e}")
    s.append(f"Alignment cos(theta): {cos_theta:.7f}")
    txt = "\n".join(s) + "\n"

    print(txt, end="")
    with open(ROOT / "stdout.txt", "a", encoding="ascii") as f:
        f.write(txt)

    # Optional: sanity asserts (loose tolerances; adjust if needed)
    # assert abs(chi_norm_K - 17.6278) < 2e-3
    # assert abs(Lambda_gate_calc - 14.050704) < 5e-4

if __name__ == "__main__":
    main()
