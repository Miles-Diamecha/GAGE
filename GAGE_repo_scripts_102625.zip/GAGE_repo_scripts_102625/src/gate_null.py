#!/usr/bin/env python3
import json

def load_gate(path="pins.json"):
    with open(path, "r") as f:
        j = json.load(f)
    return float(j["gate"]["sigma_chi"]), float(j["gate"]["K_eq_norm_chi"])

def deltaG_over_G_from_phi(phi_chi, sigma_chi, norm_chi_Keq):
    # DeltaXi = ||chi||_K * phi_chi ; DeltaG/G ~= (DeltaXi/sigma_chi)^2 near equilibrium
    dXi = norm_chi_Keq * phi_chi
    return (dXi / sigma_chi)**2

if __name__ == "__main__":
    sigma, norm = load_gate()
    phi = 1.0
    print(f"phi_chi={phi}, DeltaG/G ~= {deltaG_over_G_from_phi(phi, sigma, norm):.6e}")
